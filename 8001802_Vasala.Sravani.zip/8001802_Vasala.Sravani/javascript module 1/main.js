
console.log("Welcome to the Community Portal");
window.onload=()=>alert("Page fully loaded");

class Event{
 constructor(name,category,date,seats){
  this.name=name;this.category=category;this.date=date;this.seats=seats;
 }
}
Event.prototype.checkAvailability=function(){return this.seats>0};

let events=[];

function registrationCounter(){
 let count=0;
 return ()=>++count;
}
const totalRegistrations=registrationCounter();

function addEvent(event){events.push(event);}

function filterEventsByCategory(category,callback){
 let result=category==="All"?events:events.filter(e=>e.category===category);
 callback(result);
}

function displayEvents(list){
 const c=document.querySelector("#eventsContainer");
 c.innerHTML="";
 list.forEach(event=>{
  if(event.seats<=0)return;
  const card=document.createElement("div");
  card.className="event-card";
  card.innerHTML=`<h3>${event.name}</h3>
  <p>${event.category}</p>
  <p>Date: ${event.date}</p>
  <p>Seats: ${event.seats}</p>
  <button onclick="registerUser('${event.name}')">Register</button>`;
  c.appendChild(card);
 });
}

function registerUser(eventName){
 try{
  const event=events.find(e=>e.name===eventName);
  if(!event) throw new Error("Event not found");
  if(event.seats<=0) throw new Error("No seats available");
  event.seats--;
  displayEvents(events);
  alert("Registration Successful. Total: "+totalRegistrations());
 }catch(err){alert(err.message);}
}

document.querySelector("#categoryFilter").onchange=function(){
 filterEventsByCategory(this.value,displayEvents);
};

document.querySelector("#searchBox").addEventListener("keydown",()=>{
 const text=document.querySelector("#searchBox").value.toLowerCase();
 displayEvents(events.filter(e=>e.name.toLowerCase().includes(text)));
});

document.querySelector("#registerForm").addEventListener("submit",async function(e){
 e.preventDefault();
 const name=this.elements["name"].value;
 const email=this.elements["email"].value;
 const selectedEvent=this.elements["event"].value;

 if(!name||!email){
  document.querySelector("#message").innerText="Fill all fields";
  return;
 }

 document.querySelector("#message").innerText="Submitting...";

 setTimeout(async()=>{
  try{
   const response=await fetch("https://jsonplaceholder.typicode.com/posts",{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({name,email,selectedEvent})
   });
   await response.json();
   document.querySelector("#message").innerText="Registration Successful";
  }catch{
   document.querySelector("#message").innerText="Submission Failed";
  }
 },1500);
});

async function loadEvents(){
 document.querySelector("#spinner").classList.remove("hidden");
 try{
  const response=await fetch("events.json");
  events=await response.json();

  const select=document.querySelector("#eventSelect");
  events.forEach(e=>{
   const opt=document.createElement("option");
   opt.textContent=e.name;
   select.appendChild(opt);
  });

  console.log(Object.entries(events[0]));
  displayEvents(events);
 }catch(err){
  console.log(err);
 }
 document.querySelector("#spinner").classList.add("hidden");
}
loadEvents();

$(document).ready(function(){
 $("#registerBtn").click(function(){
   $(".event-card").fadeOut(200).fadeIn(200);
 });
});
