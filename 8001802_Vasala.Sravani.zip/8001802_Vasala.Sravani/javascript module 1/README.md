# Community Event Portal (Internship Project)

Features:
- Event Listing
- Search & Category Filter
- Registration Form
- DOM Manipulation
- Async/Await & Fetch API
- AJAX POST Request
- Closures
- Objects & Prototypes
- Array Methods
- jQuery Effects
- Error Handling

Run:
1. Open folder in VS Code
2. Install Live Server
3. Run index.html using Live Server
