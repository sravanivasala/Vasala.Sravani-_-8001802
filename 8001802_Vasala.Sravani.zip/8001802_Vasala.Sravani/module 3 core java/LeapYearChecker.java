import java.util.*;
 public class LeapYearChecker {
    public static void main(String[] a) {
        Scanner s=new Scanner(System.in); 
        int y=s.nextInt();
        System.out.println((y%400==0||(y%4==0&&y%100!=0))?"Leap Year":"Not Leap Year");
        }
    }