public class DataTypeDemo {
    public static void main(String[] a) {
        int i=10;
        float f=5.5f;
        double d=9.99;
        char c='A';
        boolean b=true;
        System.out.println(i+" "+f+" "+d+" "+c+" "+b);
        }
    }