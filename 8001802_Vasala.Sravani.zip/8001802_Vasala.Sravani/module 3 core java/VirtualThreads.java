public class VirtualThreads { 
    public static void main(String[] args) {
         System.out.println("Program 40"); 
         }
    }