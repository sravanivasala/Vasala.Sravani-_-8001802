public class ThreadCreation {
     public static void main(String[] args) {
         System.out.println("Program 26"); 
         }
    }