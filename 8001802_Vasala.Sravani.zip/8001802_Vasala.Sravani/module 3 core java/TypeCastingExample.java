public class TypeCastingExample {
    public static void main(String[] a) {
        double d=12.56;
        int i=(int)d;
        int x=20;
        double y=x;
        System.out.println(i);
        System.out.println(y);
        }
    }