public class CreateUseJavaModules { 
    public static void main(String[] args) {
         System.out.println("Program 34"); 
         }
    }