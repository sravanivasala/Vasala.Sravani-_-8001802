interface Playable {
    void play();
    }
     class Guitar implements Playable {
        public void play() {
            System.out.println("Guitar");
            }
    } 
    class Piano implements Playable {
        public void play() {
            System.out.println("Piano");
            }
        }
         public class InterfaceImplementation {
            public static void main(String[] a) {
                new Guitar().play();
                new Piano().play();
                }
        }