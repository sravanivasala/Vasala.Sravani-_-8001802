public class FileWriting { 
    public static void main(String[] args) {
         System.out.println("Program 22"); 
         }
    }