public class StreamAPI {
     public static void main(String[] args) {
         System.out.println("Program 28"); }}