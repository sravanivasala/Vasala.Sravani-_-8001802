class Animal {
    void makeSound() {
        System.out.println("Sound"); 
        } 
    } 
     class Dog extends Animal {
        void makeSound() {
            System.out.println("Bark");
            }
        }
         public class InheritanceExample {
            public static void main(String[] a) {
                new Animal().makeSound();
                new Dog().makeSound();
                }
            }