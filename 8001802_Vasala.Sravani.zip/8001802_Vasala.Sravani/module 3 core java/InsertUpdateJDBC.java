public class InsertUpdateJDBC {
     public static void main(String[] args) { 
        System.out.println("Program 32"); 
        }
    }