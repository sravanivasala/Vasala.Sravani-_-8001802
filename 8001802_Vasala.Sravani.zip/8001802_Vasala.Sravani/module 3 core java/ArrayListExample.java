public class ArrayListExample { 
    public static void main(String[] args) {
         System.out.println("Program 24"); 
         }
    }