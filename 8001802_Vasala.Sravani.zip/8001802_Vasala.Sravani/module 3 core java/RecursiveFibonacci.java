import java.util.*; 
public class RecursiveFibonacci {
    static int fib(int n) {
        return n<=1?n:fib(n-1)+fib(n-2);
        }
         public static void main(String[] a) {
            Scanner s=new Scanner(System.in);
            System.out.println(fib(s.nextInt()));
            }
        }