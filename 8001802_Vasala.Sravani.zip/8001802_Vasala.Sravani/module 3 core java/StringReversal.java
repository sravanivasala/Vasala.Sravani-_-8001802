import java.util.*;
 public class StringReversal {
    public static void main(String[] a) {
        Scanner s=new Scanner(System.in);
        String str=s.nextLine();
        System.out.println(new StringBuilder(str).reverse());
        }
    }