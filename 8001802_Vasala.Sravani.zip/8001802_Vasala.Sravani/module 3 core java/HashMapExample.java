public class HashMapExample {
     public static void main(String[] args) {
         System.out.println("Program 25"); 
         }
    }