public class LambdaExpressions {
     public static void main(String[] args) {
         System.out.println("Program 27"); 
         }
    }