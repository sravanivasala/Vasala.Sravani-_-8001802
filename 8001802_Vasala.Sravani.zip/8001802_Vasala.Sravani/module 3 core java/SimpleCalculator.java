import java.util.*; 
public class SimpleCalculator { 
    public static void main(String[] a) {
        Scanner s=new Scanner(System.in);
        double x=s.nextDouble(),y=s.nextDouble(); 
        char op=s.next().charAt(0);switch(op) { 
            case '+':
                System.out.println(x+y);break;
                case '-':
                    System.out.println(x-y);
                    break; 
                    case '*':
                        System.out.println(x*y);
                        break;
                        case '/':
                            System.out.println(x/y);
                            }
                   }
            }