public class CustomException {
     public static void main(String[] args) {
         System.out.println("Program 21"); 
         }
    }