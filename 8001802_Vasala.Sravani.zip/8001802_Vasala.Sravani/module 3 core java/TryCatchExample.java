import java.util.*;
 public class TryCatchExample {
    public static void main(String[] a) {
        Scanner s=new Scanner(System.in);
        try {
            System.out.println(s.nextInt()/s.nextInt());
            }
            catch(ArithmeticException e) {
                System.out.println("Cannot divide by zero");
                }
            }
        }