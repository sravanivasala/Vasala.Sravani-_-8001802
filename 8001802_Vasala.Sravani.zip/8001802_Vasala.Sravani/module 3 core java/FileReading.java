public class FileReading {
     public static void main(String[] args) {
         System.out.println("Program 23");
          }
    }