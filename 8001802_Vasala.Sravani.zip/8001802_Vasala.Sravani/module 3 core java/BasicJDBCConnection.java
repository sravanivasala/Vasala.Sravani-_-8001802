public class BasicJDBCConnection {
     public static void main(String[] args) {
         System.out.println("Program 31");
          }
        }