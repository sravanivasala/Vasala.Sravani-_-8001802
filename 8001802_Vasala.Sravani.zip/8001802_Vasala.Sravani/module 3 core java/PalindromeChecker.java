import java.util.*;
 public class PalindromeChecker {
    public static void main(String[] a) {
        Scanner s=new Scanner(System.in);
        String str=s.nextLine().replaceAll("[^a-zA-Z0-9]","").toLowerCase();
        String rev=new StringBuilder(str).reverse().toString();
        System.out.println(str.equals(rev));
        }
    }